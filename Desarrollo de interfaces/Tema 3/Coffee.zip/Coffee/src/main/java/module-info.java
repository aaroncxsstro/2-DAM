module com.mycompany.coffee {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.coffee to javafx.fxml;
    exports com.mycompany.coffee;
}
